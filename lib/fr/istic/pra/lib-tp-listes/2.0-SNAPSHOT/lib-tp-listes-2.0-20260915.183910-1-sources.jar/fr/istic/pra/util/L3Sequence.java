package fr.istic.pra.util;

/**
 * Interface pour une séquence avec sentinelle L3Sequence<T>.
 * 
 * Il s'agit d'une liste bouclée sur elle-même, avec un élément spécial appelé sentinelle (ou flag) qui marque la fin de la séquence.
 * Le voisin gauche de la sentinelle est le dernier élément de la séquence, et le voisin droit de la sentinelle est le premier élément de la séquence.
 * 
 * La sequence vide est représentée par la sentinelle seule.
 *
 * @param <T> le type des éléments de la séquence
 */
public interface L3Sequence<T> {
    /**
     * Crée un itérateur posé sur la tête de la séquence (ou sur la sentinelle si la séquence est vide).
     * @return un itérateur bidirectionnel sur la séquence
     */
    L3Iterator<T> l3Iterator();

    /**
     * Vérifie si la séquence est vide.
     * @return true si la séquence est vide, false sinon
     */
    boolean isEmpty();

    /**
     * Vide la séquence.
     */
    void clear();

    /**
     * Ajoute un élément à la tête de la séquence.
     * @param value la valeur de l'élément à ajouter
     */
    void addHead(T value);

    /**
     * Ajoute un élément à la queue de la séquence.
     * @param value la valeur de l'élément à ajouter
     */
    void addTail(T value);

    /**
     * Définit la valeur de la sentinelle.
     * @param value la valeur de la sentinelle
     */
    void setFlag(T value);
}
