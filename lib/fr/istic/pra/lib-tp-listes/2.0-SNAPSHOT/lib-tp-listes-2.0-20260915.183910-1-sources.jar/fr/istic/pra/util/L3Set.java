package fr.istic.pra.util;

import java.util.ArrayList;
import java.util.List;

/**
 * Interface pour un ensemble L3Set<T> avec des opérations de base sur les ensembles.
 * 
 * L3Set est une collection d'éléments uniques. Il est itérable au sens Java (interface Iterable<T>) et fournit des méthodes pour vérifier l'inclusion, la différence, l'intersection et l'union avec d'autres ensembles.
 * Les méthodes par défaut permettent de manipuler les ensembles sans avoir besoin de réimplémenter ces opérations dans chaque classe qui implémente L3Set.
 * 
 * @param <T> le type des éléments de l'ensemble
 */
public interface L3Set<T> extends java.lang.Iterable<T> {
    /**
     * Vérifie si l'ensemble contient un élément donné.
     * @param value l'élément à rechercher
     * @return true si l'élément est présent, false sinon
     */
    boolean contains(Object value);

    /**
     * Ajoute un élément à l'ensemble.
     * @param value l'élément à ajouter
     */
    void add(T value);

    /**
     * Supprime un élément de l'ensemble.
     * @param value l'élément à supprimer
     */
    void remove(T value);

    /**
     * Vide l'ensemble.
     */
    void clear();

    /**
     * Retourne le nombre d'éléments dans l'ensemble.
     * @return la taille de l'ensemble
     * @implSpec Cette méthode doit être implémentée en temps constant.
     */
    int size();

    /**
     * Retourne une copie de l'ensemble.
     * @return une copie de l'ensemble
     */
    L3Set<T> copy();

    /**
     * Vérifie si l'ensemble est vide.
     * @return true si l'ensemble est vide, false sinon
     */
    default boolean isEmpty() {
        return size() == 0;
    }

    /**
     * Vérifie si l'ensemble courant est inclus dans un autre ensemble.
     * @param set2 l'ensemble dans lequel on vérifie l'inclusion
     * @return true si l'ensemble courant est inclus dans set2, false sinon
     */
    default boolean isIncludedIn(L3Set<T> set2) {
        if (this == set2) {
            return true;
        }
        if (this.size() > set2.size()) {
            return false;
        }
        for (T elem : this) {
            if (!set2.contains(elem)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Calcule la différence de l'ensemble courant avec un autre ensemble, en modifiant l'ensemble courant.
     * @param otherSet l'ensemble à soustraire
     */
    default void difference(L3Set<T> otherSet) {
        if (this == otherSet) {
            this.clear();
            return;
        }
        for (T elem : otherSet) {
            this.remove(elem);
        }
    }

    /**
     * Calcule la différence symétrique (XOR) de l'ensemble courant avec un autre ensemble, en modifiant l'ensemble courant.
     * @param otherSet l'ensemble à utiliser pour le calcul
     */
    default void symmetricDifference(L3Set<T> otherSet) {
        if (this == otherSet) {
            this.clear();
            return;
        }
        for (T elem : otherSet) {
            if (this.contains(elem)) {
                this.remove(elem);
            } else {
                this.add(elem);
            }
        }
    }

    /**
     * Calcule l'intersection de l'ensemble courant avec un autre ensemble, en modifiant l'ensemble courant.
     * @param otherSet l'ensemble avec lequel on calcule l'intersection
     */
    default void intersection(L3Set<T> otherSet) {
        if (this == otherSet) {
            return; // Intersection with itself is the same set
        }
        // 1. Identification sans mutation de 'this'
        List<T> toRemove = new ArrayList<>();
        for (T elem : this) {
            if (!otherSet.contains(elem)) {
                toRemove.add(elem);
            }
        }
        // 2. Suppression effective après la fin du parcours
        for (T elem : toRemove) {
            this.remove(elem);
        }
        // for (T elem : this) {
        //     if (!otherSet.contains(elem)) {
        //         this.remove(elem);
        //     }
        // }
    }

    /**
     * Calcule l'union de l'ensemble courant avec un autre ensemble, en modifiant l'ensemble courant.
     * @param otherSet l'ensemble avec lequel on calcule l'union
     */
    default void union(L3Set<T> otherSet) {
        if (this == otherSet) {
            return; // Union with itself is the same set
        }
        for (T elem : otherSet) {
            this.add(elem);
        }
    }

    /**
     * Algorithme générique de comparaison entre deux ensembles L3Set.
     * 
     * @implNote Cette méthode peut être utilisée pour implémenter equals(Object) dans les classes qui implémentent L3Set.
     * 
     * @param a le premier ensemble
     * @param b le deuxième ensemble
     * @return true si les ensembles sont égaux, false sinon
     */
    static boolean equals(L3Set<?> a, Object b) {
        if (a == b) return true;
        if (!(b instanceof L3Set<?> other)) return false;
        if (a.size() != other.size()) return false;

        // Si la taille est identique, il suffit de vérifier l'inclusion
        for (Object elem : a) {
            if (!other.contains(elem)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Calcule le hashCode canonique d'un ensemble : la somme commutative
     * des hashCodes de ses éléments.
     * 
     * @implSpec Cette méthode peut être utilisée pour implémenter la méthode hashCode d'un ensemble L3Set.
     * 
     * @param set l'ensemble pour lequel on calcule le hashCode
     * @return le hashCode calculé (somme des hashCodes des éléments)
     */
    static int hashCode(L3Set<?> set) {
        int h = 0;
        for (Object obj : set) {
            if (obj != null) {
                h += obj.hashCode();
            }
        }
        return h;
    }
}
