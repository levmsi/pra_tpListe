package fr.istic.pra.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;

class SortedListSetAdapter<T> extends CollectionSetAdapter<T> {

    private final Comparator<? super T> comparator;
    private final boolean randomAccess;

    SortedListSetAdapter(List<T> delegate) {
        super(delegate, false);
        this.comparator = null;
        this.randomAccess = delegate instanceof RandomAccess;
    }

    SortedListSetAdapter(List<T> delegate, Comparator<? super T> comparator) {
        super(delegate, false);
        this.comparator = comparator;
        this.randomAccess = delegate instanceof RandomAccess;
    }

    private List<T> getList() {
        return (List<T>) super.getDelegate();
    }

    @SuppressWarnings("unchecked")
    private int compare(T a, T b) {
        if (comparator != null) {
            return comparator.compare(a, b);
        }
        return ((Comparable<? super T>) a).compareTo(b);
    }

    @Override
    public boolean contains(Object value) {
        if (!randomAccess) {
            return super.contains(value);
        }
        try {
            @SuppressWarnings("unchecked")
            T typed = (T) value;
            return binarySearchIndex(typed) >= 0;
        } catch (ClassCastException e) {
            return false;
        }
    }

    @Override
    public void add(T value) {
        if (randomAccess) {
            addRandomAccess(value);
        } else {
            addLinked(value);
        }
    }

    private void addRandomAccess(T value) {
        List<T> list = getList();
        int idx = binarySearchIndex(value);
        if (idx >= 0) {
            return; // déjà présent
        }
        list.add(-idx - 1, value);
    }

    private void addLinked(T value) {
        List<T> list = getList();
        ListIterator<T> it = list.listIterator();
        while (it.hasNext()) {
            T current = it.next();
            int c = compare(current, value);
            if (c == 0) return;
            if (c > 0) { it.previous(); it.add(value); return; }
        }
        it.add(value);
    }

    @Override
    public void remove(T value) {
        if (!randomAccess) {
            super.remove(value);
            return;
        }
        List<T> list = getList();
        int idx = binarySearchIndex(value);
        if (idx >= 0) {
            list.remove(idx);
        }
    }

    /**
     * Indice dichotomique sur la liste triée (réservé à l'accès aléatoire).
     * Renvoie l'indice de {@code value} si présent, sinon -(point d'insertion)-1.
     */
    @SuppressWarnings("unchecked")
    private int binarySearchIndex(T value) {
        List<T> list = getList();
        if (comparator != null) {
            return Collections.binarySearch(list, value, comparator);
        }
        Comparator<T> natural = (a, b) -> ((Comparable<? super T>) a).compareTo(b);
        return Collections.binarySearch(list, value, natural);
    }

    @Override
    public void union(L3Set<T> otherSet) {
        if (this == otherSet) return;
        if (!isMergeable(otherSet)) { super.union(otherSet); return; }
        List<T> o = otherAsList(otherSet);
        List<T> r = new ArrayList<>(this.size() + o.size());
        Iterator<T> it1 = getList().iterator();
        Iterator<T> it2 = o.iterator();
        T a = nextOrNull(it1), b = nextOrNull(it2);
        while (a != null && b != null) {
            int c = compare(a, b);
            if (c < 0)      { r.add(a); a = nextOrNull(it1); }
            else if (c > 0) { r.add(b); b = nextOrNull(it2); }
            else            { r.add(a); a = nextOrNull(it1); b = nextOrNull(it2); }
        }
        while (a != null) { r.add(a); a = nextOrNull(it1); }
        while (b != null) { r.add(b); b = nextOrNull(it2); }
        replaceWith(r);
    }

    @Override
    public void intersection(L3Set<T> otherSet) {
        if (this == otherSet) return;
        if (!isMergeable(otherSet)) { super.intersection(otherSet); return; }
        List<T> o = otherAsList(otherSet);
        List<T> r = new ArrayList<>(Math.min(this.size(), o.size()));
        Iterator<T> it1 = getList().iterator();
        Iterator<T> it2 = o.iterator();
        T a = nextOrNull(it1), b = nextOrNull(it2);
        while (a != null && b != null) {
            int c = compare(a, b);
            if (c < 0)      a = nextOrNull(it1);
            else if (c > 0) b = nextOrNull(it2);
            else            { r.add(a); a = nextOrNull(it1); b = nextOrNull(it2); }
        }
        replaceWith(r);
    }

    @Override
    public void difference(L3Set<T> otherSet) {
        if (this == otherSet) { this.clear(); return; }
        if (!isMergeable(otherSet)) { super.difference(otherSet); return; }
        List<T> o = otherAsList(otherSet);
        List<T> r = new ArrayList<>(this.size());
        Iterator<T> it1 = getList().iterator();
        Iterator<T> it2 = o.iterator();
        T a = nextOrNull(it1), b = nextOrNull(it2);
        while (a != null && b != null) {
            int c = compare(a, b);
            if (c < 0)      { r.add(a); a = nextOrNull(it1); }
            else if (c > 0) b = nextOrNull(it2);
            else            { a = nextOrNull(it1); b = nextOrNull(it2); }
        }
        while (a != null) { r.add(a); a = nextOrNull(it1); }
        replaceWith(r);
    }

    @Override
    public void symmetricDifference(L3Set<T> otherSet) {
        if (this == otherSet) { this.clear(); return; }
        if (!isMergeable(otherSet)) { super.symmetricDifference(otherSet); return; }
        List<T> o = otherAsList(otherSet);
        List<T> r = new ArrayList<>(this.size() + o.size());
        Iterator<T> it1 = getList().iterator();
        Iterator<T> it2 = o.iterator();
        T a = nextOrNull(it1), b = nextOrNull(it2);
        while (a != null && b != null) {
            int c = compare(a, b);
            if (c < 0)      { r.add(a); a = nextOrNull(it1); }
            else if (c > 0) { r.add(b); b = nextOrNull(it2); }
            else            { a = nextOrNull(it1); b = nextOrNull(it2); }
        }
        while (a != null) { r.add(a); a = nextOrNull(it1); }
        while (b != null) { r.add(b); b = nextOrNull(it2); }
        replaceWith(r);
    }

    @Override
    public boolean isIncludedIn(L3Set<T> set2) {
        if (this == set2) return true;
        if (this.size() > set2.size()) return false;
        if (!isMergeable(set2)) return super.isIncludedIn(set2);
        List<T> o = otherAsList(set2);
        Iterator<T> it1 = getList().iterator();
        Iterator<T> it2 = o.iterator();
        T a = nextOrNull(it1), b = nextOrNull(it2);
        while (a != null && b != null) {
            int c = compare(a, b);
            if (c < 0) return false;
            else if (c > 0) b = nextOrNull(it2);
            else { a = nextOrNull(it1); b = nextOrNull(it2); }
        }
        return a == null;
    }

    private static <E> E nextOrNull(Iterator<E> it) {
        return it.hasNext() ? it.next() : null;
    }

    private boolean isMergeable(L3Set<T> other) {
        if (!(other instanceof SortedListSetAdapter<?> o)) return false;
        return comparator == null ? o.comparator == null : comparator.equals(o.comparator);
    }

    private List<T> otherAsList(L3Set<T> other) {
        return ((SortedListSetAdapter<T>) other).getList();
    }

    private void replaceWith(List<T> result) {
        List<T> list = getList();
        list.clear();
        list.addAll(result);
    }

    @Override
    public L3Set<T> copy() {
        List<T> copied = new ArrayList<>(getList());
        return comparator != null
                ? new SortedListSetAdapter<>(copied, comparator)
                : new SortedListSetAdapter<>(copied);
    }
}