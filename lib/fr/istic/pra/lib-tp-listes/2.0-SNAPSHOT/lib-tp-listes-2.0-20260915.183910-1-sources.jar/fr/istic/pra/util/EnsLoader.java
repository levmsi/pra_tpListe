package fr.istic.pra.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.util.List;
import java.util.Scanner;
import java.util.function.Consumer;

/**
 * Lecture de fichiers d'ensembles (.ens) embarqués sur le classpath.
 *
 * Format : entiers séparés par des blancs, terminés par la sentinelle -1.
 * Indépendant de tout code legacy ; uniquement conçu pour alimenter un L3Set.
 */
public final class EnsLoader {

	/** Valeur sentinelle qui marque la fin d'un fichier .ens. */
	public static final int STOP = -1;

	private static final String[] SAMPLES = {
		"f0.ens", "f1.ens", "f2.ens", "f3.ens", "f4.ens",
		"test-desordre.ens", "test-d01.ens", "test-d03.ens", "test-d05.ens", "test-d30.ens",
		"test-i03.ens", "test-s01.ens", "test-u01.ens", "test-u03.ens"
	};

	private EnsLoader() {
	}

	/**
	 * @return la liste des fichiers .ens disponibles sur le classpath.
	 */
	public static List<String> sampleNames() {
		return List.of(SAMPLES);
	}

	/**
	 * Lit un fichier .ens et ajoute les valeurs lues (jusqu'à la sentinelle)
	 * dans l'ensemble fourni.
	 *
	 * @param resourceName nom de la ressource (ex. "f0.ens"), sans '/' initial.
	 * @param into         ensemble à remplir.
	 * @throws IllegalArgumentException si la ressource est introuvable.
	 */
	public static void readInto(String resourceName, L3Set<Integer> into) {
		readValues(resourceName, into::add);
	}

	/**
	 * Lit un fichier .ens et retire de l'ensemble fourni les valeurs lues
	 * (jusqu'à la sentinelle).
	 *
	 * @param resourceName nom de la ressource (ex. "f1.ens"), sans '/' initial.
	 * @param from         ensemble à modifier.
	 * @throws IllegalArgumentException si la ressource est introuvable.
	 */
	public static void readRemove(String resourceName, L3Set<Integer> from) {
		readValues(resourceName, from::remove);
	}

	/**
	 * Parcourt un fichier .ens et applique {@code action} à chaque valeur
	 * jusqu'à la sentinelle STOP.
	 */
	public static void readValues(String resourceName, Consumer<Integer> action) {
		try (InputStream in = EnsLoader.class.getResourceAsStream("/" + resourceName)) {
			if (in == null) {
				throw new IllegalArgumentException("ressource introuvable : " + resourceName);
			}
			Scanner sc = new Scanner(in);
			while (sc.hasNextInt()) {
				int value = sc.nextInt();
				if (value == STOP) {
					break;
				}
				action.accept(value);
			}
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		}
	}
}
