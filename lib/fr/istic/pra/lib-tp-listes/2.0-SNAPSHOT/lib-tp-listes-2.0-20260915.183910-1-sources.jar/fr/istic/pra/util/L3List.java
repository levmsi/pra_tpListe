package fr.istic.pra.util;

import java.util.LinkedList;

/**
 * Implémentation fournie de {@link L3Sequence} basée sur un adaptateur de
 * {@link java.util.LinkedList}.
 *
 * <p>Le « flag » est virtuel : l'itérateur est considéré posé sur le flag
 * lorsqu'il se trouve en bout de liste. La valeur du flag (stockée par
 * {@link #setFlag}) est rendue par {@code getValue()} lorsque l'itérateur est
 * sur le flag, pour rester compatible avec le modèle à sentinelle.</p>
 *
 * @param <T> type des valeurs
 */
public class L3List<T> implements L3Sequence<T> {
	static {
		// Affichage d'un message pour indiquer que la version fournie de L3List est utilisée
		System.out.println("L3List : version fournie par lib-tp-listes");
	}

	/** Liste chaînée déléguée. */
	private final LinkedList<T> delegate = new LinkedList<>();

	/** La valeur portée par le flag (jamais lue en pratique, conservée par compat). */
	private T flagValue;

	public L3List() {
	}

	/**
	 * Itérateur adaptant {@link java.util.ListIterator} au modèle à sentinelle.
	 *
	 * <p>L'élément courant est l'élément précédent le curseur ({@code li.previous()}).
	 * Les opérations {@code next()} / {@code previous()} d'un {@code LinkedList}
	 * {@code ListIterator} avancent de nœud en nœud en O(1) : il n'y a donc
	 * jamais d'accès par index ({@code get(index)} / {@code add(index, v)}) qui,
	 * sur une liste chaînée, seraient en O(index).</p>
	 */
	private class L3ListIterator implements L3Iterator<T> {
		/** Curseur {@code ListIterator}, l'élément courant étant {@code li.previous()}. */
		private java.util.ListIterator<T> li;
		/** true si le curseur est posé sur le flag (fin de liste après le dernier élément). */
		private boolean onFlag = true;

		private L3ListIterator() {
			this.restart();
		}

		@Override
		public boolean isOnFlag() {
			return onFlag;
		}

		@Override
		public void restart() {
			li = delegate.listIterator();
			if (!delegate.isEmpty()) {
				li.next();
			}
			onFlag = delegate.isEmpty();
		}

		@Override
		public void goForward() {
			if (!onFlag) {
				if (li.nextIndex() == delegate.size()) {
					onFlag = true;
				} else {
					li.next();
				}
				return;
			}
			// sur le flag : on avance vers le premier élément de liste
			if (!delegate.isEmpty()) {
				li = delegate.listIterator();
				li.next();
				onFlag = false;
			}
		}

		@Override
		public void goBackward() {
			if (!onFlag) {
				if (li.previousIndex() == 0) {
					onFlag = true;
				} else {
					li.previous();
				}
				return;
			}
			// sur le flag : on recule vers le dernier élément de liste
			if (!delegate.isEmpty()) {
				li = delegate.listIterator(delegate.size());
				onFlag = false;
			}
		}

		@Override
		public T getValue() {
			if (onFlag) {
				return flagValue;
			}
			T v = li.previous();
			li.next();
			return v;
		}

		@Override
		public T nextValue() {
			goForward();
			return getValue();
		}

		@Override
		public void remove() {
			if (onFlag) {
				throw new IllegalStateException("impossible de retirer la sentinelle");
			}
			li.previous();
			li.remove();
			if (li.hasNext()) {
				li.next();
			} else {
				onFlag = true;
			}
		}

		@Override
		public void addLeft(T v) {
			if (onFlag) {
				// à gauche du flag = insertion en queue de liste
				delegate.addLast(v);
				li = delegate.listIterator(delegate.size());
				onFlag = false;
			} else {
				li.previous();
				li.add(v);
			}
		}

		@Override
		public void addRight(T v) {
			if (onFlag) {
				if (delegate.isEmpty()) {
					addLeft(v);
				} else {
					delegate.addFirst(v);
					li = delegate.listIterator();
					li.next();
					onFlag = false;
				}
			} else {
				li.add(v);
			}
		}

		@Override
		public void setValue(T v) {
			if (onFlag) {
				flagValue = v;
				return;
			}
			li.previous();
			li.set(v);
			li.next();
		}
	}

	@Override
	public L3Iterator<T> l3Iterator() {
		return new L3ListIterator();
	}

	@Override
	public boolean isEmpty() {
		return delegate.isEmpty();
	}

	@Override
	public void clear() {
		delegate.clear();
	}

	@Override
	public void addHead(T v) {
		delegate.addFirst(v);
	}

	@Override
	public void addTail(T v) {
		delegate.addLast(v);
	}

	@Override
	public void setFlag(T v) {
		this.flagValue = v;
	}

	@Override
	public String toString() {
		StringBuilder s = new StringBuilder("contenu de la liste : \n");
		L3Iterator<T> p = l3Iterator();
		while (!p.isOnFlag()) {
			s.append(p.getValue()).append(' ');
			p.goForward();
		}
		return s.toString();
	}
}
