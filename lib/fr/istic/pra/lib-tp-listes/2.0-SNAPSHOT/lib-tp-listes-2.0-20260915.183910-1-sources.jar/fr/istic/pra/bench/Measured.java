package fr.istic.pra.bench;

/**
 * Un point de mesure : une opération, une implémentation, un scénario.
 * Structure figée pour être affichée/tracée par ton propre code.
 */
public record Measured(
        String impl,          // nom de l'implémentation (HashSet, Sparse, SortedArr...)
        String scenario,      // nom du scénario (ex : "dense-10k", "sparse-10k")
        String operation,     // nom de l'opération (BUILD, CONTAINS, UNION...)
        int size,             // taille de l'ensemble
        double density,       // densité du scénario (size / domain)
        int samples,          // nombre d'échantillons réellement collectés
        double medianNanos,   // temps médian en ns (robuste aux outliers GC)
        double minNanos,
        double maxNanos
) {}