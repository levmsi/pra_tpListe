package fr.istic.pra.bench;

/** Un scénario de données : un nom, une taille, et une génération. */
public record DataScenario(String name, int size, DataGen gen, long domain) {
    /** Densité = fraction de l'espace occupée : size / domain. */
    public double density() {
        return domain <= 0 ? 1.0 : (double) size / domain;
    }
}