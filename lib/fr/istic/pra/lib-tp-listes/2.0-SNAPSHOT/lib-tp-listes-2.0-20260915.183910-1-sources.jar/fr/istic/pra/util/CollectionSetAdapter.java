package fr.istic.pra.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 * Adaptateur L3Set porté par une Collection Java quelconque.
 *
 * <p>Deux configurations :</p>
 * <ul>
 *   <li><b>Ensemble natif</b> (HashSet, LinkedHashSet, TreeSet) : {@code nativelyUnique == true},
 *       l'unicité et (pour TreeSet) le tri sont gérés par la collection.</li>
 *   <li><b>Liste</b> (ArrayList, LinkedList, sans ordre significatif) :
 *       {@code nativelyUnique == false}, l'unicité est garantie par l'adaptateur.</li>
 * </ul>
 *
 * <p>Les opérations ensemblistes délèguent aux méthodes natives de Collection
 * (addAll/retainAll/removeAll/containsAll).</p>
 *
 * @param <T> le type des éléments
 */
class CollectionSetAdapter<T> implements L3Set<T> {

    private final Collection<T> delegate;
    private final boolean nativelyUnique;

    CollectionSetAdapter(Collection<T> delegate, boolean nativelyUnique) {
        this.delegate = delegate;
        this.nativelyUnique = nativelyUnique;
    }

    @Override
    public boolean contains(Object value) {
        return delegate.contains(value);
    }

    @Override
    public void add(T value) {
        if (!nativelyUnique && delegate.contains(value)) {
            return; // une liste n'empêche pas les doublons nativement
        }
        delegate.add(value);
    }

    @Override
    public void remove(T value) {
        delegate.remove(value);
    }

    @Override
    public void clear() {
        delegate.clear();
    }

    @Override
    public int size() {
        return delegate.size();
    }

    @Override
    public Iterator<T> iterator() {
        return delegate.iterator();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof L3Set<?> other) {
            return L3Set.equals(this, other);
        }
        return false;
    }

    @Override
    public int hashCode() {
        return L3Set.hashCode(this);
    }

    @Override
    public String toString() {
        return delegate.toString();
    }

    // ===== Accès interne (pour la fusion / copie) =====
    Collection<T> getDelegate() {
        return delegate;
    }

    boolean isNativelyUnique() {
        return nativelyUnique;
    }

    // ===== Opérations ensemblistes =====

    /**
     * Ajoute tous les éléments de {@code other} sans créer de doublon.
     * Contrairement à Collection.addAll (qui peut dupliquer sur une liste),
     * cette méthode garantit l'unicité.
     */
    private void addAllUnique(Collection<T> other) {
        if (nativelyUnique) {
            delegate.addAll(other); // les Set absorbent les doublons nativement
        } else {
            Collection<T> newOnes = new ArrayList<>(other);
            newOnes.removeAll(delegate); // ne garde que ce qui est absent de this
            delegate.addAll(newOnes);
        }
    }

    @Override
    public void union(L3Set<T> otherSet) {
        if (this == otherSet) {
            return;
        }
        if (otherSet instanceof CollectionSetAdapter<?> adapter) {
            @SuppressWarnings("unchecked")
            Collection<T> other = (Collection<T>) adapter.getDelegate();
            addAllUnique(other);
        } else {
            for (T elem : otherSet) {
                this.add(elem);
            }
        }
    }

    @Override
    public void intersection(L3Set<T> otherSet) {
        if (this == otherSet) {
            return;
        }
        if (otherSet instanceof CollectionSetAdapter<?> adapter) {
            @SuppressWarnings("unchecked")
            Collection<T> other = (Collection<T>) adapter.getDelegate();
            delegate.retainAll(other);
        } else {
            L3Set.super.intersection(otherSet);
        }
    }

    @Override
    public void difference(L3Set<T> otherSet) {
        if (this == otherSet) {
            this.clear();
            return;
        }
        if (otherSet instanceof CollectionSetAdapter<?> adapter) {
            @SuppressWarnings("unchecked")
            Collection<T> other = (Collection<T>) adapter.getDelegate();
            delegate.removeAll(other);
        } else {
            L3Set.super.difference(otherSet);
        }
    }

    @Override
    public void symmetricDifference(L3Set<T> otherSet) {
        if (this == otherSet) {
            this.clear();
            return;
        }
        if (otherSet instanceof CollectionSetAdapter<?> adapter) {
            @SuppressWarnings("unchecked")
            Collection<T> other = (Collection<T>) adapter.getDelegate();
            // (this \ other) ∪ (other \ this)
            Collection<T> onlyOther = new ArrayList<>(other);
            onlyOther.removeAll(delegate);  // other \ this
            delegate.removeAll(other);      // this \ other
            addAllUnique(onlyOther);        // réunit sans doublons
        } else {
            L3Set.super.symmetricDifference(otherSet);
        }
    }

    @Override
    public boolean isIncludedIn(L3Set<T> set2) {
        if (this == set2) {
            return true;
        }
        if (this.size() > set2.size()) {
            return false;
        }
        if (set2 instanceof CollectionSetAdapter<?> adapter) {
            @SuppressWarnings("unchecked")
            Collection<T> other = (Collection<T>) adapter.getDelegate();
            return delegate.containsAll(other);
        }
        for (T elem : this) {
            if (!set2.contains(elem)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public L3Set<T> copy() {
        Collection<T> copied = nativelyUnique
                ? new java.util.HashSet<>(delegate)
                : new ArrayList<>(delegate);
        return new CollectionSetAdapter<>(copied, nativelyUnique);
    }
}