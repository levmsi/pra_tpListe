package fr.istic.pra.bench;

import fr.istic.pra.util.L3Set;
import java.util.function.Supplier;

/**
 * Une implémentation de L3Set à benchmarker.
 * Le Supplier crée un ensemble VIDE à chaque appel (état frais).
 */
public record L3Impl(String name, Supplier<L3Set<Integer>> factory) {}