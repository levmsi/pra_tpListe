package fr.istic.pra.bench;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.LongSupplier;

/**
 * Timer adaptatif et robuste aux outliers.
 *
 * <ul>
 *   <li><b>Adaptatif</b> : le nombre de répétitions dépend d'un budget
 *       temporel (pas d'un nombre fixe). Méthodes rapides → beaucoup de
 *       répétitions (amortit les outliers GC dans les temps courts) ;
 *       méthodes lentes → peu de répétitions (pas d'allongement inutile).</li>
 *   <li><b>Warmup sur données distinctes</b> : le warmup est délégué à la
 *       tâche (qui bascule sur d'autres données) pour ne pas fausser la
 *       prédiction de branche du CPU.</li>
 *   <li><b>Médiane</b> : retourne la médiane, insensible aux outliers.</li>
 * </ul>
 */
public final class AdaptiveTimer {

    /** Politique de mesure. */
    public record Policy(
            long budgetNanos,   // budget temporel par mesure
            int minRepeats,     // nb minimal d'échantillons (garde-fou)
            int maxRepeats,     // plafond d'échantillons (garde-fou)
            int warmupRounds,   // tours de warmup
            long warmupNanos    // budget warmup (repli sur warmupRounds)
    ) {
        public static Policy millis(long budgetMs, int min, int max, int warmupRounds) {
            return new Policy(budgetMs * 1_000_000L, min, max,
                    warmupRounds, 300 * 1_000_000L);
        }
        public static Policy defaultPolicy() {
            return millis(100, 5, 1_000_000, 3);
        }
    }

    private final Policy policy;

    public AdaptiveTimer(Policy policy) {
        this.policy = policy;
    }

    /** Résultat d'une mesure : nb d'échantillons + médiane/min/max (ns). */
    public record Sample(int count, double median, double min, double max) {}

    /**
     * Warmup seul (jusqu'à stabilisation), sans mesure. Destiné à chauffer
     * une implémentation UNE fois, sur une petite taille, hors des mesures.
     */
    public void warmup(Runnable warmup) {
        doWarmup(warmup);
    }

    /**
     * Mesure une tâche de façon adaptative, avec warmup.
     *
     * @param bench  exécution de mesure, renvoyant la durée (ns) de l'ACTION
     *               SEULE (le rig est construit avant, hors du chronométrage)
     * @param warmup exécution de warmup (sur des données DIFFÉRENTES)
     */
    public Sample measure(LongSupplier bench, Runnable warmup) {
        doWarmup(warmup);
        return measure(bench);
    }

    /**
     * Mesure une tâche SANS warmup (le warmup doit déjà avoir été fait via
     * {@link #warmup(Runnable)}).
     */
    public Sample measure(LongSupplier bench) {
        List<Long> samples = new ArrayList<>();
        long t0 = System.nanoTime();
        while (samples.size() < policy.maxRepeats()) {
            if (samples.size() >= policy.minRepeats()
                    && System.nanoTime() - t0 >= policy.budgetNanos()) {
                break;
            }
            samples.add(bench.getAsLong());
        }
        return summarize(samples);
    }

    private void doWarmup(Runnable warmup) {
        long t0 = System.nanoTime();
        double prev = Double.NaN;
        for (int round = 0; round < policy.warmupRounds(); round++) {
            int n = 200;
            long s = System.nanoTime();
            for (int i = 0; i < n; i++) warmup.run();
            double cur = (double) (System.nanoTime() - s) / n;
            // stabilité : dérive < 10% entre deux tours → on s'arrête
            if (!Double.isNaN(prev) && Math.abs(cur - prev) / Math.max(prev, 1e-9) < 0.10) {
                break;
            }
            prev = cur;
            if (System.nanoTime() - t0 > policy.warmupNanos()) break;
        }
    }

    private static Sample summarize(List<Long> samples) {
        if (samples.isEmpty()) return new Sample(0, 0, 0, 0);
        long[] a = new long[samples.size()];
        for (int i = 0; i < a.length; i++) a[i] = samples.get(i);
        Arrays.sort(a);
        int n = a.length;
        double median = n % 2 == 1 ? a[n / 2] : (a[n / 2 - 1] + a[n / 2]) / 2.0;
        return new Sample(n, median, a[0], a[n - 1]);
    }
}