package fr.istic.pra.bench;

import fr.istic.pra.util.L3Set;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * Orchestre le benchmark : pour chaque (implémentation × scénario × opération),
 * produit un point de mesure.
 *
 * <p>Le « rig » (THIS rempli, éventuellement OTHER) est construit par ajouts
 * successifs UNE fois de plus et conservé comme prototype ; chaque instance
 * fraîche est ensuite dérivée par {@code copy()} (optimisé pour chaque
 * structure), beaucoup plus rapide que des ajouts répétés. Le rig n'est donc
 * pas construit à chaque échantillon, seul l'objet de mesure est chronométré.
 */
public final class L3SetBench {

    private final AdaptiveTimer timer;
    private final long seed;

    public L3SetBench(AdaptiveTimer timer, long seed) {
        this.timer = timer;
        this.seed = seed;
    }

    /** Mesure toutes les opérations pour une implémentation et un scénario (avec warmup). */
    public List<Measured> run(L3Impl impl, DataScenario scenario, List<Op> ops) {
        return measureAll(impl, scenario, ops, true);
    }

    /** Mesure SANS warmup : le warmup doit avoir été fait au préalable (voir {@link #warmup}). */
    public List<Measured> runSkippingWarmup(L3Impl impl, DataScenario scenario, List<Op> ops) {
        return measureAll(impl, scenario, ops, false);
    }

    /**
     * Warmup complet (jusqu'à stabilisation) d'une implémentation sur un
     * scénario — à appeler UNE fois, de préférence sur la plus petite taille,
     * avant la batterie de mesures.
     */
    public void warmup(L3Impl impl, DataScenario scenario, List<Op> ops) {
        ScenarioData data = scenario.gen().sample(scenario.size(), seed);
        for (Op op : ops) {
            Rig rig = buildRig(impl.factory(), op, data.a(), data.b(), data.c());
            timer.warmup(() -> opNanos(op, rig, data.a()));
        }
    }

    private List<Measured> measureAll(L3Impl impl, DataScenario scenario,
                                      List<Op> ops, boolean doWarmup) {
        ScenarioData data = scenario.gen().sample(scenario.size(), seed);
        List<Measured> out = new ArrayList<>();

        for (Op op : ops) {
            Rig benchRig = buildRig(impl.factory(), op, data.a(), data.b(), data.c());
            Rig warmupRig = doWarmup
                    ? buildRig(impl.factory(), op, data.b(), data.a(), data.c())
                    : null; // warmup : données distinctes

            AdaptiveTimer.Sample s = doWarmup
                    ? timer.measure(
                            () -> opNanos(op, benchRig, data.a()),
                            () -> opNanos(op, warmupRig, data.b()))
                    : timer.measure(() -> opNanos(op, benchRig, data.a()));

            out.add(new Measured(
                    impl.name(), scenario.name(), op.name(),
                    scenario.size(), scenario.density(),
                    s.count(), s.median(), s.min(), s.max()));
        }
        return out;
    }

    /** Construit le prototype du rig pour une opération. */
    private static Rig buildRig(Supplier<L3Set<Integer>> factory, Op op,
                                int[] dataA, int[] dataB, int[] probe) {
        L3Set<Integer> thisProto = op.prefill() ? build(factory, dataA) : null;
        L3Set<Integer> otherProto = op.needsOther() ? build(factory, dataB) : null;
        return new Rig(factory, thisProto, otherProto, probe);
    }

    /** Dérive une instance fraîche par copy() et chronomètre UNIQUEMENT l'action. */
    private static long opNanos(Op op, Rig rig, int[] fill) {
        L3Set<Integer> set = rig.freshThis();
        L3Set<Integer> other = rig.freshOther();

        long t0 = System.nanoTime();
        op.run(set, other, rig.probe, fill);
        return System.nanoTime() - t0;
    }

    /**
     * Rig prêt à mesurer : prototypes remplis (par ajouts) + sonde.
     * freshThis()/freshOther() produisent une copie fraîche via copy().
     */
    private static final class Rig {
        final Supplier<L3Set<Integer>> factory;
        final L3Set<Integer> thisProto;   // null → THIS est vide (cas BUILD)
        final L3Set<Integer> otherProto;  // null → pas d'OTHER
        final int[] probe;

        Rig(Supplier<L3Set<Integer>> factory, L3Set<Integer> thisProto,
            L3Set<Integer> otherProto, int[] probe) {
            this.factory = factory;
            this.thisProto = thisProto;
            this.otherProto = otherProto;
            this.probe = probe;
        }

        L3Set<Integer> freshThis() {
            return thisProto == null ? factory.get() : thisProto.copy();
        }

        L3Set<Integer> freshOther() {
            return otherProto == null ? null : otherProto.copy();
        }
    }

    private static L3Set<Integer> build(Supplier<L3Set<Integer>> factory, int[] data) {
        L3Set<Integer> s = factory.get();
        for (int v : data) s.add(v);
        return s;
    }
}
