package fr.istic.pra.bench;

/**
 * Trois jeux de données pour un scénario.
 *
 * @param a l'ensemble principal (taille `size`) — remplit THIS.
 * @param b second ensemble (taille `size`) — remplit OTHER des opérations binaires.
 * @param c sonde de taille fixe (<i>probe</i>) — utilisée par contains/addOne/remove ;
 *          moitié des valeurs présentes dans {@code a}, moitié absentes.
 */
public record ScenarioData(int[] a, int[] b, int[] c) {
    public int size() { return a.length; }
}
