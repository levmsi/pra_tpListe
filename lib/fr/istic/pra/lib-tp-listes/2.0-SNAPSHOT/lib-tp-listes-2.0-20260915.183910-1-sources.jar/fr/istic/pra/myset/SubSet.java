package fr.istic.pra.myset;

public class SubSet implements Comparable<SubSet> {

	final int rank;
	final SmallSet set;

	public SubSet() {
		rank = 0;
		set = new SmallSet();
	}

	public SubSet(int rank, SmallSet smallSet) {
		this.rank = rank;
		this.set = smallSet;
	}

	public SubSet(SubSet subset) {
		this.rank = subset.rank;
		this.set = new SmallSet(subset.set);
	}

	@Override
	public String toString() {
		return "Subset [rank=" + rank + ", set=" + set + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof SubSet)) {
			return false;
		}
		SubSet other = (SubSet) obj;
		return rank == other.rank && set.equals(other.set);
	}

	@Override
	public int compareTo(SubSet otherSubSet) {
		return Integer.compare(this.rank, otherSubSet.rank);
	}
}