package fr.istic.pra.util;

/**
 * Interface pour un iterateur bidirectionnel sur une liste avec sentinelle L3Sequence<T>.
 *
 * @param <T> le type des éléments de la liste
 */
public interface L3Iterator<T> {
    /**
     * Déplace l'itérateur vers l'élément suivant.
     */
    void goForward();

    /**
     * Déplace l'itérateur vers l'élément précédent.
     */
    void goBackward();

    /**
     * Remet l'itérateur sur la tête de la liste (ou la sentinelle si la liste est vide).
     */
    void restart();

    /**
     * Vérifie si l'itérateur est sur la sentinelle.
     * @return true si l'itérateur est sur la sentinelle, false sinon
     */
    boolean isOnFlag();

    /**
     * Supprime l'élément courant.
     * @apiNote Cette méthode ne doit être appelée que si l'itérateur n'est pas sur la sentinelle.
     */
    void remove();

    /**
     * Récupère la valeur de l'élément courant.
     * @return la valeur de l'élément courant
     */
    T getValue();

    /**
     * Déplace l'itérateur vers l'élément suivant et retourne sa valeur.
     * @return la valeur du nouvel élément courant
     */
    T nextValue();

    /**
     * Ajoute un élément à gauche de l'élément courant.
     * @param v la valeur de l'élément à ajouter
     */
    void addLeft(T v);

    /**
     * Ajoute un élément à droite de l'élément courant.
     * @param v la valeur de l'élément à ajouter
     */
    void addRight(T v);
    
    /**
     * Modifie la valeur de l'élément courant.
     * @param v la nouvelle valeur de l'élément
     */
    void setValue(T v);
}
