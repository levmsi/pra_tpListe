package fr.istic.pra.myset;

import java.util.BitSet;
import java.util.Iterator;

import fr.istic.pra.util.L3Set;


public class SmallSet implements L3Set<Integer> {
	static {
		// Affichage d'un message pour indiquer que la version fournie de SmallSet est utilisée
		System.out.println("SmallSet : version fournie par lib-tp-listes");
	}

	/**
	 * taille de l'ensemble
	 */
	public static final int SET_SIZE = 256;

	/**
	 * Ensemble est représenté par un bitSet d'indication d'appartenance.
	 */
	private BitSet bitSet = new BitSet(SET_SIZE);

	public SmallSet() {
		this.bitSet.clear();
	}

	// public SmallSet(boolean[] array) {
	// 	this.tab = Arrays.copyOf(array, SET_SIZE);
	// }

	public SmallSet(SmallSet set) {
		// this.tab = Arrays.copyOf(set.tab, SET_SIZE);
		this.bitSet = (BitSet) set.bitSet.clone();
	}


	public Iterator<Integer> iterator() {
		return bitSet.stream().iterator();
	}

	@Override
	public L3Set<Integer> copy() {
		return new SmallSet(this);
	}

	/**
	 * @return nombre de valeurs appartenant à l’ensemble
	 */
	@Override
	public int size() {
		return this.bitSet.cardinality();
	}

	/**
	 * @param x valeur à tester
	 * @return true, si l’entier x appartient à l’ensemble, false sinon
	 */
	@Override
	public boolean contains(Object x) {
		if (!(x instanceof Integer)) {
			return false;
		}
		int xi = (Integer) x;
		return xi >= 0 && xi < 256 && this.bitSet.get(xi);
	}

	/**
	 * @return true, si l’ensemble est vide, false sinon
	 */
	@Override
	public boolean isEmpty() {
		return this.size() == 0;
	}

	/**
	 * Ajoute x à l’ensemble (sans effet si x déjà présent)
	 *
	 * @param x valeur à ajouter
	 * @pre 0 <= x <= 255
	 */
	@Override
	public void add(Integer x) {
		if (x >= 0 && x < SET_SIZE) {
			this.bitSet.set(x);
		}
	}

	/**
	 * Retire x de l’ensemble (sans effet si x n’est pas présent)
	 *
	 * @param x valeur à supprimer
	 * @pre 0 <= x <= 255
	 */
	@Override
	public void remove(Integer x) {
		if (x >= 0 && x < SET_SIZE) {
			this.bitSet.clear(x);
		}
	}

	/**
	 * Ajoute à l’ensemble les valeurs deb, deb+1, deb+2, ..., fin.
	 *
	 * @param begin début de l’intervalle
	 * @param end   fin de l’intervalle
	 * @pre 0 <= begin <= end <= 255
	 */
	public void addInterval(int deb, int fin) {
		int vraiDebut = deb >= 0 ? deb : 0;
		int vraieFin = fin < SET_SIZE ? fin : SET_SIZE - 1;

		bitSet.set(vraiDebut, vraieFin + 1);
	}

	/**
	 * Retire de l’ensemble les valeurs deb, deb+1, deb+2, ..., fin.
	 *
	 * @param begin début de l’intervalle
	 * @param end   fin de l’intervalle
	 * @pre 0 <= begin <= end <= 255
	 */
	public void removeInterval(int deb, int fin) {
		int vraiDebut = deb >= 0 ? deb : 0;
		int vraieFin = fin < SET_SIZE ? fin : SET_SIZE - 1;

		bitSet.clear(vraiDebut, vraieFin + 1);
	}

	/**
	 * this devient l'union de this et set2
	 * 
	 * @param set2 deuxième ensemble
	 */
	@Override
	public void union(L3Set<Integer> set2) {
		if (set2 instanceof SmallSet otherSet) {
			this.bitSet.or(otherSet.bitSet);
		} else {
			L3Set.super.union(set2);
		}
	}

	/**
	 * this devient l'intersection de this et set2
	 * 
	 * @param set2 deuxième ensemble
	 */
	@Override
	public void intersection(L3Set<Integer> set2) {
		if (set2 instanceof SmallSet otherSet) {
			this.bitSet.and(otherSet.bitSet);
		} else {
			L3Set.super.intersection(set2);
		}
	}

	/**
	 * this devient la différence de this et set2
	 * 
	 * @param set2 deuxième ensemble
	 */
	@Override
	public void difference(L3Set<Integer> set2) {
		if (set2 instanceof SmallSet otherSet) {
			this.bitSet.andNot(otherSet.bitSet);
		} else {
			L3Set.super.difference(set2);
		}
	}

	/**
	 * this devient la différence symétrique de this et set2
	 * 
	 * @param set2 deuxième ensemble
	 */
	@Override
	public void symmetricDifference(L3Set<Integer> set2) {
		if (set2 instanceof SmallSet otherSet) {
			this.bitSet.xor(otherSet.bitSet);
		} else {
			L3Set.super.symmetricDifference(set2);
		}
	}

	/**
	 * this devient le complément de this.
	 */
	public void complement() {
		this.bitSet.flip(0, SET_SIZE);
	}

	/**
	 * this devient l'ensemble vide.
	 */
	@Override
	public void clear() {
		this.bitSet.clear();
	}

	/**
	 * @param set2 second ensemble
	 * @return true, si this est inclus dans set2, false sinon
	 */
	@Override
	public boolean isIncludedIn(L3Set<Integer> set2) {
		if (set2 instanceof SmallSet otherSet) {
			BitSet temp = (BitSet) this.bitSet.clone();
			temp.and(otherSet.bitSet);
			return temp.equals(this.bitSet);
		} else {
			return L3Set.super.isIncludedIn(set2);
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof SmallSet other) {
			return this.bitSet.equals(other.bitSet);
		} else {
			return L3Set.super.equals(obj);
		}
	}

	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		bitSet.stream().forEach(value -> {
			result.append(value).append(" ");
		});
		return result.toString();
	}
}
