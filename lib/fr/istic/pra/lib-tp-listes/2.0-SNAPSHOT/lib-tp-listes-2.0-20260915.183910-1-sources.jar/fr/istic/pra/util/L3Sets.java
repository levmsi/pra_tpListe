package fr.istic.pra.util;

import java.util.*;

public final class L3Sets {
    private L3Sets() {}

    // ---- Ensembles : HashSet / LinkedHashSet / TreeSet ----
    public static <T> L3Set<T> hashSet()       { return new CollectionSetAdapter<>(new HashSet<>(), true); }
    public static <T> L3Set<T> linkedHashSet() { return new CollectionSetAdapter<>(new LinkedHashSet<>(), true); }
    public static <T> L3Set<T> treeSet()       { return new CollectionSetAdapter<>(new TreeSet<>(), true); }

    // ---- Listes non triées ----
    public static <T> L3Set<T> arrayList()     { return new CollectionSetAdapter<>(new ArrayList<>(), false); }
    public static <T> L3Set<T> linkedList()    { return new CollectionSetAdapter<>(new LinkedList<>(), false); }

    // ---- Listes triées (fusion par itérateurs) ----
    public static <T extends Comparable<? super T>> L3Set<T> sortedArrayList() {
        return new SortedListSetAdapter<>(new ArrayList<>());
    }
    public static <T extends Comparable<? super T>> L3Set<T> sortedLinkedList() {
        return new SortedListSetAdapter<>(new LinkedList<>());
    }
    public static <T> L3Set<T> sortedList(Comparator<? super T> cmp) {
        return new SortedListSetAdapter<>(new ArrayList<>(), cmp);
    }

    // ---- Envelopper une collection existante ----
    public static <T> L3Set<T> of(Set<T> set)         { return new CollectionSetAdapter<>(set, true); }
    public static <T> L3Set<T> of(List<T> list)       { return new CollectionSetAdapter<>(list, false); }
    public static <T> L3Set<T> sorted(List<T> list)   { return new SortedListSetAdapter<>(list); }
}