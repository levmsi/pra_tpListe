package fr.istic.pra.bench;

/**
 * Génère les données d'un scénario : deux jeux de `size` entiers distincts
 * plus une sonde de taille fixe.
 * a → remplit l'ensemble principal (this).
 * b → remplit le second ensemble (other) des opérations binaires.
 * c → sonde de taille fixe pour les opérations de requête (contains/addOne/remove),
 *      moitié présent dans `a`, moitié absent.
 */
@FunctionalInterface
public interface DataGen {
    ScenarioData sample(int size, long seed);
}
