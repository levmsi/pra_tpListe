package fr.istic.pra.bench;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Set;

/** Générateurs de données selon la densité/éparsité. */
public final class DataGens {
    private DataGens() {}

    /** Taille de la sonde (c) utilisée par contains/addOne/remove. */
    public static final int PROBE_SIZE = 100;

    /**
     * Dense : les entiers de [0, size) sont présents → densité 1.
     * other = mêmes valeurs mais décalées (distinct de this).
     * sonde : moitié dans [0, size), moitié dans [size, size + 50) (absent de this).
     */
    public static DataGen dense(int domain) {
        return (size, seed) -> {
            int[] a = new int[size];
            int[] b = new int[size];
            for (int i = 0; i < size; i++) {
                a[i] = i;
                b[i] = (i + size / 2) % domain;
            }
            return new ScenarioData(a, b, probeFrom(a, i -> size + i, seed));
        };
    }

    /**
     * Épars : `size` entiers tirés uniformément sur un domaine symétrique
     * [-domain/2, domain/2). Densité ≈ size/domain.
     * this et other sont générés avec des graines différentes → distincts,
     * mais avec un recouvrement aléatoire représentatif.
     * sonde : moitié des valeurs de `a`, moitié tirée hors de `a`.
     */
    public static DataGen sparse(int domain) {
        return (size, seed) -> {
            int[] a = unique(size, new Random(seed), domain);
            int[] b = unique(size, new Random(seed ^ 0x9E3779B97F4A7C15L), domain);
            Set<Integer> inA = new HashSet<>();
            for (int v : a) inA.add(v);
            int[] c = new int[PROBE_SIZE];
            for (int i = 0; i < PROBE_SIZE / 2; i++) {
                c[i] = a[i % a.length];
            }
            Random rnd = new Random(seed ^ 0xC2B2AE3D27D4EB4FL);
            for (int i = PROBE_SIZE / 2; i < PROBE_SIZE; i++) {
                int v;
                do {
                    v = rnd.nextInt(domain) - domain / 2;
                } while (inA.contains(v));
                c[i] = v;
            }
            return new ScenarioData(a, b, c);
        };
    }

    /**
     * Clusters : `size` entiers tirés uniformément sur un domaine symétrique
     * [-domain/2, domain/2), mais regroupés en clusters de `k` valeurs consécutives.
     * this et other sont générés avec des graines différentes → distincts,
     * mais avec un recouvrement aléatoire représentatif.
     * sonde : moitié des valeurs de `a`, moitié tirée hors de `a
     */
    public static DataGen clusters(int domain, int k) {
        return (size, seed) -> {
            int[] a = new int[size];
            int[] b = new int[size];
            Random rndA = new Random(seed);
            Random rndB = new Random(seed ^ 0x9E3779B97F4A7C15L);
            Set<Integer> inA = new HashSet<>();
            for (int i = 0; i < size; i += k) {
                int clusterStartA = rndA.nextInt(domain - k);
                for (int j = 0; j < k && i + j < size; j++) {
                    a[i + j] = clusterStartA + j;
                    inA.add(a[i + j]);
                }
                int clusterStartB = rndB.nextInt(domain - k);
                for (int j = 0; j < k && i + j < size; j++) {
                    b[i + j] = clusterStartB + j;
                }
            }
            int[] c = new int[PROBE_SIZE];
            for (int i = 0; i < PROBE_SIZE / 2; i++) {
                c[i] = a[i % a.length];
            }
            Random rndC = new Random(seed ^ 0xC2B2AE3D27D4EB4FL);
            for (int i = PROBE_SIZE / 2; i < PROBE_SIZE; i++) {
                int v;
                do {
                    v = rndC.nextInt(domain) - domain / 2;
                } while (inA.contains(v));
                c[i] = v;
            }
            return new ScenarioData(a, b, c);
        };
    }

    /** Sonde : PROBE_SIZE/2 valeurs de `a`, PROBE_SIZE/2 valeurs absentes. */
    private static int[] probeFrom(int[] a, java.util.function.IntUnaryOperator absent, long seed) {
        int[] c = new int[PROBE_SIZE];
        for (int i = 0; i < PROBE_SIZE / 2; i++) {
            c[i] = a[i % a.length];
        }
        for (int i = PROBE_SIZE / 2; i < PROBE_SIZE; i++) {
            c[i] = absent.applyAsInt(i);
        }
        return c;
    }

    private static int[] unique(int size, Random rnd, int domain) {
        LinkedHashSet<Integer> seen = new LinkedHashSet<>();
        while (seen.size() < size) seen.add(rnd.nextInt(domain) - domain / 2);
        int[] d = new int[size];
        int i = 0;
        for (int v : seen) d[i++] = v;
        return d;
    }
}
