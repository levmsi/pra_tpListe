package fr.istic.pra.bench;

import fr.istic.pra.util.L3Set;

/**
 * Catalogue fermé des opérations de benchmark L3Set.
 *
 * <p>Chaque opération décrit le « rig » dont elle a besoin (construit HORS du
 * chronométrage) et l'action réellement mesurée :
 * <ul>
 *   <li>{@code prefill} : true → THIS arrive déjà rempli de `size` éléments ;
 *       false → il arrive vide (cas BUILD : on mesure la construction).</li>
 *   <li>{@code DataKind} : quel second jeu de données est utilisé.
 *       OTHER → un second ensemble complet (données b), PROBE → la sonde fixe (données c),
 *       NONE → aucune donnée externe.</li>
 * </ul>
 */
public enum Op {

    // ---- Unaires ----
    BUILD(false, DataKind.NONE) {
        void run(L3Set<Integer> s, L3Set<Integer> o, int[] probe, int[] fill) {
            for (int v : fill) s.add(v);
        }
    },
    ADD_ONE(true, DataKind.PROBE) {
        void run(L3Set<Integer> s, L3Set<Integer> o, int[] probe, int[] fill) {
            for (int v : probe) s.add(v);
        }
    },
    CONTAINS(true, DataKind.PROBE) {
        void run(L3Set<Integer> s, L3Set<Integer> o, int[] probe, int[] fill) {
            for (int v : probe) s.contains(v);
        }
    },
    REMOVE(true, DataKind.PROBE) {
        void run(L3Set<Integer> s, L3Set<Integer> o, int[] probe, int[] fill) {
            for (int v : probe) s.remove(v);
        }
    },
    ITERATE(true, DataKind.NONE) {
        void run(L3Set<Integer> s, L3Set<Integer> o, int[] probe, int[] fill) {
            int acc = 0;
            for (int v : s) acc += v;
        }
    },
    COPY(true, DataKind.NONE) {
        void run(L3Set<Integer> s, L3Set<Integer> o, int[] probe, int[] fill) {
            s.copy();
        }
    },

    // ---- Binaires : other est du même type, rempli avec les données b ----
    UNION(true, DataKind.OTHER) {
        void run(L3Set<Integer> s, L3Set<Integer> o, int[] probe, int[] fill) { s.union(o); }
    },
    INTERSECTION(true, DataKind.OTHER) {
        void run(L3Set<Integer> s, L3Set<Integer> o, int[] probe, int[] fill) { s.intersection(o); }
    },
    DIFFERENCE(true, DataKind.OTHER) {
        void run(L3Set<Integer> s, L3Set<Integer> o, int[] probe, int[] fill) { s.difference(o); }
    },
    SYMMETRIC_DIFFERENCE(true, DataKind.OTHER) {
        void run(L3Set<Integer> s, L3Set<Integer> o, int[] probe, int[] fill) { s.symmetricDifference(o); }
    },
    IS_INCLUDED_IN(true, DataKind.OTHER) {
        void run(L3Set<Integer> s, L3Set<Integer> o, int[] probe, int[] fill) { s.isIncludedIn(o); }
    };

    private final boolean prefill;
    private final DataKind kind;

    Op(boolean prefill, DataKind kind) {
        this.prefill = prefill;
        this.kind = kind;
    }

    public boolean prefill()  { return prefill; }
    public boolean needsOther() { return kind == DataKind.OTHER; }

    /** Exécute l'action mesurée (le rig est déjà construit). */
    abstract void run(L3Set<Integer> set, L3Set<Integer> other, int[] probe, int[] fill);

    enum DataKind { NONE, PROBE, OTHER }
}
